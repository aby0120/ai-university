# C 语言教材配套源码

AI 编写；代码 MIT，原创说明 CC0-1.0。
project/ 是完整成绩管理器，按其中 README 构建。
examples/ 每个目录是一个独立完整程序；不要把多个 main.c 一起链接。

进入某个案例目录，macOS 可将 gcc 换成 clang：

gcc -std=c17 -Wall -Wextra -Wpedantic main.c -o example
./example < stdin.txt

MSYS2 也可用 ./example.exe。stdout.txt、stderr.txt、exit-code.txt 是预期，
不属于要编译的代码。部分案例故意拒绝非法输入，会以非零状态结束，
例如显示 invalid；这是已定义的错误处理，不是运行未定义行为。
其他 .txt 文件是该案例要读取的固定夹具，请保持在案例当前目录。
全书正文和答案见同版 C-Programming.md；每次只编译当前案例。
