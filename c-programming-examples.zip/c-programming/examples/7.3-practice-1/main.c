#include <stdio.h>

int main(void)
{
    printf("%u\n", 1U << 3);
    return 0;
}
