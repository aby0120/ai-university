#include <stdio.h>

int main(void)
{
    printf("%zu\n", sizeof(char));
    return 0;
}
