#include <stdio.h>
int larger(int a, int b);
int main(void)
{
    printf("%d\n", larger(2, 9));
    return 0;
}
int larger(int a, int b)
{
    return a > b ? a : b;
}
