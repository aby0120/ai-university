#include <stdio.h>

int main(void)
{
    int a[4] = {7};
    for (size_t i = 0; i < 4; i++) {
        printf("%d\n", a[i]);
    }
    return 0;
}
