#include <stdio.h>

int next_local(void)
{
    int n = 0;
    n++;
    return n;
}

int main(void)
{
    printf("%d\n", next_local());
    printf("%d\n", next_local());
    return 0;
}
