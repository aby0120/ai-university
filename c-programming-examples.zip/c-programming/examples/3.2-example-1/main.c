#include <stdio.h>

int square(int value)
{
    return value * value;
}

int main(void)
{
    printf("%d\n", square(4));
    return 0;
}
