#include <stdio.h>

int next_static(void)
{
    static int n = 0;
    n++;
    return n;
}

int main(void)
{
    printf("%d\n", next_static());
    printf("%d\n", next_static());
    return 0;
}
