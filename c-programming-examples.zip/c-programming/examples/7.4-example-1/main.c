#include <stdio.h>
#include <assert.h>

int accepts(int score)
{
    return score >= 0 && score <= 100;
}

int main(void)
{
    assert(!accepts(-1));
    assert(accepts(0));
    assert(accepts(100));
    assert(!accepts(101));
    puts("ok");
    return 0;
}
