#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("missing.txt", "r");
    if (fp == NULL) { puts("cannot open"); return 1; }
    fclose(fp);
    return 0;
}
