#include <stdio.h>

int main(void)
{
    int score = 60;
    if (score >= 60) {
        puts("pass");
    } else {
        puts("retry");
    }
    return 0;
}
