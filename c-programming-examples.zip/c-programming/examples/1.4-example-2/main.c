#include <stdio.h>

int main(void)
{
    int seconds = 185;
    printf("%d min %d sec\n", seconds / 60, seconds % 60);
    return 0;
}
