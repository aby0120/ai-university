#include <stdio.h>

int main(void)
{
    int age = 0;
    if (scanf("%d", &age) != 1) {
        puts("invalid input");
        return 1;
    }
    printf("%d\n", age);
    return 0;
}
