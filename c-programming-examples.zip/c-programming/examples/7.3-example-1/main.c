#include <stdio.h>

int main(void)
{
    const unsigned READ = 1U, WRITE = 2U;
    unsigned flags = READ;
    flags |= WRITE;
    printf("%u %d\n", flags, (flags & WRITE) != 0);
    return 0;
}
