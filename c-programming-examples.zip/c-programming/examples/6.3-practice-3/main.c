#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("a.txt", "r");
    if (fp == NULL) { return 1; }
    size_t count = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) { count++; }
    int bad = ferror(fp);
    if (fclose(fp) != 0) { bad = 1; }
    if (bad) { return 1; }
    printf("%zu\n", count);
    return 0;
}
