#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("note.txt", "w");
    if (fp == NULL) { return 1; }
    if (fputs("one\ntwo\n", fp) == EOF) { fclose(fp); return 1; }
    if (fclose(fp) != 0) { return 1; }
    fp = fopen("note.txt", "r");
    if (fp == NULL) { return 1; }
    char line[16];
    while (fgets(line, sizeof line, fp) != NULL) { printf("%s", line); }
    int bad = ferror(fp);
    if (fclose(fp) != 0) { bad = 1; }
    if (bad) { return 1; }
    return 0;
}
