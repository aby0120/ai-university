#include <stdio.h>
#include <string.h>

int main(void)
{
    char a[] = "hi", b[] = "hi";
    printf("%d\n", strcmp(a, b) == 0);
    return 0;
}
