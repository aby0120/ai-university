#include <stdio.h>

int main(void)
{
    int t = 30;
    if (t >= 0 && t <= 30) {
        puts("normal");
    } else {
        puts("outside");
    }
    return 0;
}
