#include <stdio.h>

int main(void)
{
    int count = 3;
    double temperature = 18.5;
    char level = 'A';
    printf("%d %.1f %c\n", count, temperature, level);
    return 0;
}
