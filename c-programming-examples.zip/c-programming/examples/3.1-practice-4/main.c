#include <stdio.h>

int main(void)
{
    for (int r = 0; r < 3; r++) {
        for (int c = 1; c <= 2; c++) {
            printf("%d", c);
        }
        putchar('\n');
    }
    return 0;
}
