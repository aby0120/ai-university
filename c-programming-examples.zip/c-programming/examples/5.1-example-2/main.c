#include <stdio.h>

int main(void)
{
    int a = 1, b = 2;
    int *p = &a;
    p = &b;
    *p = 9;
    printf("%d %d\n", a, b);
    return 0;
}
