#include <stdio.h>
#include <assert.h>

int minimum(const int *a, size_t n, int *out)
{
    if(n==0 || out==NULL){ return 0; }
    int best=a[0];
    for(size_t i=1;i<n;i++){ if(a[i]<best){ best=a[i]; } }
    *out=best;
    return 1;
}

int main(void)
{
    int a[]={4,-2,7};
    int result=99;
    assert(minimum(a,3,&result)==1);
    assert(result==-2);
    assert(minimum(a,0,&result)==0);
    assert(result==-2);
    printf("%d\n",result);
    return 0;
}
