#include <stdio.h>

int main(void)
{
    int x = 2;
    {
        int x = 9;
        printf("%d\n", x);
    }
    printf("%d\n", x);
    return 0;
}
