#include <stdio.h>

int main(void)
{
    double mean = (2 + 3) / 2.0;
    printf("%.1f\n", mean);
    return 0;
}
