#include <stdio.h>

int main(void)
{
    int a[] = {1, 2};
    size_t result = 2;
    for (size_t i = 0; i < 2; i++) {
        if (a[i] == 9) { result = i; break; }
    }
    printf("%zu\n", result);
    return 0;
}
