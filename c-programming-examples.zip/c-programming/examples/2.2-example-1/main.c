#include <stdio.h>

int main(void)
{
    int age = 0;
    if (scanf("%d", &age) != 1 || age < 0 || age > 150) {
        puts("invalid age");
        return 1;
    }
    printf("%d\n", age + 1);
    return 0;
}
