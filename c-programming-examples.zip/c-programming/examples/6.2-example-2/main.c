#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(4 * sizeof *a);
    if (a == NULL) { return 1; }
    size_t size = 2;
    a[0] = 3; a[1] = 5;
    int sum = 0;
    for (size_t i = 0; i < size; i++) { sum += a[i]; }
    printf("%d\n", sum);
    free(a);
    return 0;
}
