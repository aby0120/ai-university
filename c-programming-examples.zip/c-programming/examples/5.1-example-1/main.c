#include <stdio.h>

int main(void)
{
    int value = 5;
    int *p = &value;
    *p = 8;
    printf("%d\n", value);
    return 0;
}
