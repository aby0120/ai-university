#include <stdio.h>

int main(void)
{
    int n = 17;
    if (n % 2 == 0) {
        puts("even");
    } else {
        puts("odd");
    }
    return 0;
}
