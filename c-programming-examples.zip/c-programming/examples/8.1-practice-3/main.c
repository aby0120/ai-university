#include <stdio.h>

int main(void)
{
    int scores[] = {59, 60};
    int passed = 0;
    for (size_t i = 0; i < 2; i++) { if (scores[i] >= 60) { passed++; } }
    printf("%d\n", passed);
    return 0;
}
