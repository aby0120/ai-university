#include <stdio.h>

int main(void)
{
    int a[]={5,2,5,1};
    size_t count=0;
    for(size_t i=0;i<4;i++){ if(a[i]==5){ count++; } }
    printf("%zu\n",count);
    return 0;
}
