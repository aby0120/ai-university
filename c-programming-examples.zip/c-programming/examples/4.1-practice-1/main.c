#include <stdio.h>

int main(void)
{
    int a[] = {2, 4, 6};
    int sum = 0;
    for (size_t i = 0; i < 3; i++) { sum += a[i]; }
    printf("%.1f\n", sum / 3.0);
    return 0;
}
