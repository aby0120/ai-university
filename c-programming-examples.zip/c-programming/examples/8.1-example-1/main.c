#include <stdio.h>

int main(void)
{
    int total = 88 + 59 + 100;
    printf("count=3 total=%d mean=%.2f pass=2\n", total, total / 3.0);
    return 0;
}
