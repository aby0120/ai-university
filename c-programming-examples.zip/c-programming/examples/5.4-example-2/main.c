#include <stdio.h>

void fill(int *a)
{
    a[0] = 7;
    a[1] = 9;
}

int main(void)
{
    int a[2] = {0};
    fill(a);
    printf("%d %d\n", a[0], a[1]);
    return 0;
}
