#include <stdio.h>
#include <string.h>

int main(void)
{
    char line[8];
    if (fgets(line, sizeof line, stdin) == NULL) { return 1; }
    if (strchr(line, '\n') == NULL) {
        puts("line incomplete");
        return 1;
    }
    printf("%s", line);
    return 0;
}
