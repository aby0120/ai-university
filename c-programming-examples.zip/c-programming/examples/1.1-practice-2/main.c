#include <stdio.h>

int main(void)
{
    puts("Learn one step.");
    return 0;
}
