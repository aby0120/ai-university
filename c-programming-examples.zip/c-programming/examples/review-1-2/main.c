#include <stdio.h>

int main(void)
{
    printf("%.1f\n", (7 + 8 + 9) / 3.0);
    return 0;
}
