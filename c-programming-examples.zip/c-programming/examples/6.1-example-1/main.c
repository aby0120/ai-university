#include <stdio.h>

typedef struct {
    char name[21];
    int score;
} Student;

int main(void)
{
    Student s = {"Lin", 88};
    printf("%s %d\n", s.name, s.score);
    return 0;
}
