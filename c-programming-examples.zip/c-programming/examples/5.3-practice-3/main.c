#include <stdio.h>

int main(void)
{
    int a[] = {6, 7, 8};
    printf("%d %d\n", a[2], *(a + 2));
    return 0;
}
