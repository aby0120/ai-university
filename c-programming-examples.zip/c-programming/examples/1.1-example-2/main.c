#include <stdio.h>

int main(void)
{
    puts("I can code.");
    return 0;
}
