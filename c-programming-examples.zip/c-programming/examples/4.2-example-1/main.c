#include <stdio.h>

int main(void)
{
    int a[] = {4, 7, 4};
    size_t result = 3;
    for (size_t i = 0; i < 3; i++) {
        if (a[i] == 7) { result = i; break; }
    }
    printf("%zu\n", result);
    return 0;
}
