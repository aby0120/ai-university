#include <stdio.h>

int main(void)
{
    puts("\"C\"");
    return 0;
}
