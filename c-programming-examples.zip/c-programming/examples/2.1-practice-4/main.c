#include <stdio.h>

int main(void)
{
    int score = 95;
    if (score >= 90) {
        puts("A");
    } else if (score >= 60) {
        puts("B");
    } else {
        puts("C");
    }
    return 0;
}
