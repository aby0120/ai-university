#include <stdio.h>

int main(void)
{
    int a = 6, b = 4;
    printf("%d\n", a > b ? a : b);
    return 0;
}
