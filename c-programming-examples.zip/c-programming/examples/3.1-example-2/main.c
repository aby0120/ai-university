#include <stdio.h>

int main(void)
{
    for (int row = 0; row < 2; row++) {
        for (int col = 0; col < 3; col++) {
            putchar('*');
        }
        putchar('\n');
    }
    return 0;
}
