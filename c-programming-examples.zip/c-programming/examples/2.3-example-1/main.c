#include <stdio.h>

int main(void)
{
    int choice = 2;
    switch (choice) {
    case 1:
        puts("add");
        break;
    case 2:
        puts("list");
        break;
    default:
        puts("unknown");
        break;
    }
    return 0;
}
