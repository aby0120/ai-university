#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(2 * sizeof *a);
    if (a == NULL) { return 1; }
    a[0] = 5; a[1] = 6;
    printf("%d\n", a[0] * a[1]);
    free(a);
    return 0;
}
