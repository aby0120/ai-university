#include <stdio.h>

int main(void)
{
    unsigned flags = 3U;
    flags &= ~2U;
    printf("%u\n", flags);
    return 0;
}
