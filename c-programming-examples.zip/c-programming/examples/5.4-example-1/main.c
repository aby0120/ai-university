#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(3 * sizeof *a);
    if (a == NULL) { return 1; }
    a[0] = 2; a[1] = 4; a[2] = 6;
    printf("%d\n", a[0] + a[1] + a[2]);
    free(a);
    a = NULL;
    return 0;
}
