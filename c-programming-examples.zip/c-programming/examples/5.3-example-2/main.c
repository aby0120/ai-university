#include <stdio.h>

int main(void)
{
    int a[] = {10, 20, 30};
    const int *p = a;
    p++;
    printf("%d\n", *p);
    return 0;
}
