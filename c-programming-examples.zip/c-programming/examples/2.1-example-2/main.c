#include <stdio.h>

int main(void)
{
    int denominator = 0;
    if (denominator != 0 && 12 / denominator > 2) {
        puts("large");
    } else {
        puts("not available");
    }
    return 0;
}
