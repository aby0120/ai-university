#include <stdio.h>

int sum_small(const int *a, size_t n)
{
    int sum = 0;
    for (size_t i = 0; i < n; i++) { sum += a[i]; }
    return sum;
}

int main(void)
{
    int a[] = {2, 3, 4};
    printf("%d\n", sum_small(a, 3));
    return 0;
}
