#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("last.txt", "r");
    if (fp == NULL) { return 1; }
    int ch;
    while ((ch = fgetc(fp)) != EOF) { putchar(ch); }
    int bad = ferror(fp);
    if (fclose(fp) != 0) { bad = 1; }
    if (bad) { return 1; }
    putchar('\n');
    return 0;
}
