#include <stdio.h>

int main(void)
{
    puts("Path: C:\\study");
    return 0;
}
