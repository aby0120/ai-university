#include <stdio.h>

void set_zero(int *p)
{
    *p = 0;
}

int main(void)
{
    int x = 5;
    set_zero(&x);
    printf("%d\n", x);
    return 0;
}
