#include <stdio.h>

int main(void)
{
    printf("Progress: %d%%\n", 25);
    return 0;
}
