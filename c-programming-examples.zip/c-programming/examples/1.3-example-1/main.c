#include <stdio.h>

int main(void)
{
    int stock = 12;
    stock = stock - 5;
    printf("%d\n", stock);
    return 0;
}
