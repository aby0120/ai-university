#include <stdio.h>
#include <assert.h>

int main(void)
{
    int total = 100 + 88 + 59;
    assert(total == 247);
    assert(60 >= 60);
    assert(!(59 >= 60));
    puts("ready");
    return 0;
}
