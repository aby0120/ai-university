#include <stdio.h>

int main(void)
{
    int x = 4, y = 6;
    int *p = &x;
    p = &y;
    printf("%d %d %d\n", x, y, *p);
    return 0;
}
