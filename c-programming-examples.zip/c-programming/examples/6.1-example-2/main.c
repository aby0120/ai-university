#include <stdio.h>

typedef struct { char name[21]; int score; } Student;

int main(void)
{
    Student a = {"Lin", 88};
    Student b = a;
    b.score = 90;
    printf("%d %d\n", a.score, b.score);
    return 0;
}
