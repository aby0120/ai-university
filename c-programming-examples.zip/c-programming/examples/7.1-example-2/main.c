#include <stdio.h>

static int helper(int n)
{
    return n * 2;
}

int main(void)
{
    printf("%d\n", helper(4));
    return 0;
}
