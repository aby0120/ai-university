#include <stdio.h>

int main(void)
{
    size_t count = 0;
    if (count == 0) { puts("mean=n/a"); } else { printf("mean=%.2f\n", 0.0 / count); }
    return 0;
}
