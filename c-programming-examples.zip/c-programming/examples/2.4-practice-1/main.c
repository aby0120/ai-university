#include <stdio.h>

int main(void)
{
    int n = 0;
    while (n > 0) {
        puts("inside");
        n--;
    }
    puts("done");
    return 0;
}
