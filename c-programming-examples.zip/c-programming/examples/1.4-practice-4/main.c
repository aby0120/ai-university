#include <stdio.h>

int main(void)
{
    int change_cents = 500 - 125 * 3;
    printf("%d cents\n", change_cents);
    return 0;
}
