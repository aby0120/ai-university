#include <stdio.h>
#include <assert.h>

int main(void)
{
    int sum = 0;
    for (int i = 1; i <= 3; i++) {
        sum += i;
    }
    assert(sum == 6);
    printf("%d\n", sum);
    return 0;
}
