#include <stdio.h>

int main(void)
{
    int x = 3;
    int *p = &x;
    int *q = p;
    *q = 7;
    printf("%d\n", *p);
    return 0;
}
