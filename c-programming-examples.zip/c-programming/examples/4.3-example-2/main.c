#include <stdio.h>

int main(void)
{
    char word[] = "Cat";
    word[0] = 'B';
    puts(word);
    return 0;
}
