#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main(void)
{
    const char *text = "85abc";
    char *end;
    errno = 0;
    long value = strtol(text, &end, 10);
    if (end == text || errno == ERANGE || *end != '\0' || value < 0 || value > 100) {
        puts("invalid"); return 1;
    }
    printf("%ld\n", value);
    return 0;
}
