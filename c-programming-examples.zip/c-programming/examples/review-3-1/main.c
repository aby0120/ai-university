#include <stdio.h>
#include <assert.h>

int clamp_score(int n)
{
    if (n < 0) { return 0; }
    if (n > 100) { return 100; }
    return n;
}

int main(void)
{
    assert(clamp_score(-2)==0);
    assert(clamp_score(50)==50);
    assert(clamp_score(120)==100);
    puts("ok");
    return 0;
}
