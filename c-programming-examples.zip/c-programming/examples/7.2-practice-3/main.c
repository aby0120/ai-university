#include <stdio.h>

int main(void)
{
    unsigned long long result = 1;
    for (unsigned i = 1; i <= 5; i++) { result *= i; }
    printf("%llu\n", result);
    return 0;
}
