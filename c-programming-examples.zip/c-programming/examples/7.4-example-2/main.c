#include <stdio.h>
#include <assert.h>

int set_score(int *out, int score)
{
    if (out == NULL || score < 0 || score > 100) { return 0; }
    *out = score;
    return 1;
}

int main(void)
{
    int score = 60;
    int ok = set_score(&score, 101);
    assert(ok == 0);
    assert(score == 60);
    puts("ok");
    return 0;
}
