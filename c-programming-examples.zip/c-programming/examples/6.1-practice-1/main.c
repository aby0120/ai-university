#include <stdio.h>

typedef struct { char name[21]; int score; } Student;

int main(void)
{
    Student s = {"Bo", 70};
    Student *p = &s;
    p->score = 95;
    printf("%d\n", s.score);
    return 0;
}
