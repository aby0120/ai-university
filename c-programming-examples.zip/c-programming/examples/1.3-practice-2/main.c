#include <stdio.h>

int main(void)
{
    const double radius = 2.5;
    printf("%.1f\n", radius);
    return 0;
}
