#include <stdio.h>

int larger(int a, int b)
{
    if (a > b) { return a; }
    return b;
}

int main(void)
{
    printf("%d\n", larger(3, 8));
    return 0;
}
