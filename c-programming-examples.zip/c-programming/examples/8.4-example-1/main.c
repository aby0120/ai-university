#include <stdio.h>

int main(void)
{
    fprintf(stderr, "invalid record\n");
    return 1;
    return 0;
}
