#include <stdio.h>

int main(void)
{
    unsigned flags = 5U;
    printf("%d\n", (flags & 4U) != 0);
    return 0;
}
