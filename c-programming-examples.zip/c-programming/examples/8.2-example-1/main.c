#include <stdio.h>
#include <string.h>

int main(void)
{
    printf("%d\n", strcmp("Ada", "Bo") < 0);
    return 0;
}
