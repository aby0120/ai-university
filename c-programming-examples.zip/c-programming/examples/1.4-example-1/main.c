#include <stdio.h>

int main(void)
{
    int a = 7 / 2;
    double b = 7 / 2;
    double c = (double)7 / 2;
    printf("%d %.1f %.1f\n", a, b, c);
    return 0;
}
