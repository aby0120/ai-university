#include <stdio.h>

int add_small(int a, int b, int *out)
{
    if (out == NULL || a < 0 || a > 100 || b < 0 || b > 100) { return 0; }
    *out = a + b;
    return 1;
}

int main(void)
{
    int out = 99;
    int ok = add_small(-1, 2, &out);
    printf("%d %d\n", ok, out);
    return 0;
}
