#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(sizeof *a);
    if (a == NULL) { return 1; }
    a[0] = 7;
    int *tmp = realloc(a, 2 * sizeof *a);
    if (tmp == NULL) { free(a); return 1; }
    a = tmp;
    a[1] = 9;
    printf("%d %d\n", a[0], a[1]);
    free(a);
    return 0;
}
