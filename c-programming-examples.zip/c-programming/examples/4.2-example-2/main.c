#include <stdio.h>

int main(void)
{
    int a[] = {3, 1, 2};
    for (size_t i = 1; i < 3; i++) {
        int key = a[i];
        size_t j = i;
        while (j > 0 && a[j - 1] > key) {
            a[j] = a[j - 1];
            j--;
        }
        a[j] = key;
    }
    for (size_t i = 0; i < 3; i++) { printf("%d\n", a[i]); }
    return 0;
}
