#include <stdio.h>

int main(void)
{
    int choice = 1;
    switch (choice) {
    case 1: puts("A"); /* intentional fallthrough */
    case 2: puts("B"); break;
    default: break;
    }
    return 0;
}
