#include <stdio.h>

int twice(int n)
{
    return n * 2;
}

int main(void)
{
    printf("%d %d\n", twice(4), twice(4));
    return 0;
}
