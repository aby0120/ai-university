#include <stdio.h>
#include <assert.h>

int abs_small(int n)
{
    if (n < 0) { return -n; }
    return n;
}

int main(void)
{
    assert(abs_small(-3) == 3);
    assert(abs_small(0) == 0);
    assert(abs_small(4) == 4);
    puts("ok");
    return 0;
}
