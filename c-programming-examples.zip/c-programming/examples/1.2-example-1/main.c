#include <stdio.h>

int main(void)
{
    puts("Start");
    printf("A\nB\n");
    return 0;
}
