#include <stdio.h>

int main(void)
{
    int a[2][2] = {{1, 2}, {3, 4}};
    for (size_t r = 0; r < 2; r++) {
        int sum = 0;
        for (size_t c = 0; c < 2; c++) { sum += a[r][c]; }
        printf("%d\n", sum);
    }
    return 0;
}
