#include <stdio.h>

int main(void)
{
    const char *s = "-1";
    int valid = 1;
    for (size_t i = 0; s[i] != '\0'; i++) {
        if (s[i] < '0' || s[i] > '9') { valid = 0; break; }
    }
    printf("%d\n", valid);
    return 0;
}
