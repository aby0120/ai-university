#include <stdio.h>
#include <string.h>

int main(void)
{
    char name[] = "Lin";
    printf("%zu %zu\n", strlen(name), sizeof name);
    return 0;
}
