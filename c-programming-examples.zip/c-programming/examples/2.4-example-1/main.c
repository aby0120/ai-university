#include <stdio.h>

int main(void)
{
    int n = 3;
    while (n > 0) {
        printf("%d\n", n);
        n--;
    }
    return 0;
}
