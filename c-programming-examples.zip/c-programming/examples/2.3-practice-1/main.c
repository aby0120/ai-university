#include <stdio.h>

int main(void)
{
    int choice = 9;
    switch (choice) {
    case 1: puts("new"); break;
    default: puts("invalid"); break;
    }
    return 0;
}
