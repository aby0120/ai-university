#include <stdio.h>

int main(void)
{
    int scores[] = {70, 80, 90};
    size_t count = sizeof scores / sizeof scores[0];
    int total = 0;
    for (size_t i = 0; i < count; i++) {
        total += scores[i];
    }
    printf("%d\n", total);
    return 0;
}
