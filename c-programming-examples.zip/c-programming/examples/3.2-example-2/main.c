#include <stdio.h>

int changed(int value)
{
    value = 99;
    return value;
}

int main(void)
{
    int x = 3;
    printf("%d\n", changed(x));
    printf("%d\n", x);
    return 0;
}
