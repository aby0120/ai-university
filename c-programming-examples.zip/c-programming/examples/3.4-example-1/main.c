#include <stdio.h>
#include <assert.h>

int passes(int score)
{
    return score >= 60;
}

int main(void)
{
    assert(!passes(59));
    assert(passes(60));
    puts("ok");
    return 0;
}
