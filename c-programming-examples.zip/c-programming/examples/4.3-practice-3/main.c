#include <stdio.h>

int main(void)
{
    char s[] = "banana";
    int count = 0;
    for (size_t i = 0; s[i] != '\0'; i++) {
        if (s[i] == 'a') { count++; }
    }
    printf("%d\n", count);
    return 0;
}
