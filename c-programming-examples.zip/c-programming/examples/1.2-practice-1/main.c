#include <stdio.h>

int main(void)
{
    printf("A");
    printf("B\n");
    return 0;
}
