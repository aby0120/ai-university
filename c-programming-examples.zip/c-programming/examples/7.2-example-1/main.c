#include <stdio.h>

unsigned long long fact(unsigned n)
{
    if (n == 0) { return 1; }
    return n * fact(n - 1);
}

int main(void)
{
    printf("%llu\n", fact(3));
    return 0;
}
