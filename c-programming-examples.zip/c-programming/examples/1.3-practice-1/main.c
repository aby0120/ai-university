#include <stdio.h>

int main(void)
{
    int x = 4;
    x = x + 2;
    x = x + 2;
    printf("%d\n", x);
    return 0;
}
