#include <stdio.h>

typedef struct { char name[21]; int score; } Student;

int main(void)
{
    Student a = {"Lin", 88}, b = {"Bo", 59};
    Student temp = a; a = b; b = temp;
    printf("%s %d\n%s %d\n", a.name, a.score, b.name, b.score);
    return 0;
}
