#include <stdio.h>

int main(void)
{
    int day = 1;
    switch (day) {
    case 1:
    case 2:
        puts("weekday");
        break;
    default:
        puts("other");
        break;
    }
    return 0;
}
